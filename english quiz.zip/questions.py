quiz = {
    1 : {
        "question" : "Thirty, forty, ________?",
        "answer" : "fifty"
    },
    2 : {
        "question" : "Sunday, ____________, Tuesday",
        "answer" : "Monday"
    },
    3 : {
        "question" : "We've (spended/spent) a lot of money today.",
        "answer" : "spent"
    },
    4 : {
        "question" : "tnua (unscramble)",
        "answer" : "tuna"
    },
    5 : {
        "question" : "He (is/has/are) very hungry right now.",
        "answer" : "is"
    },
    6 : {
        "question" : "Is this book (yours/your/her)?",
        "answer" : "yours"
    },
    7 : {
       "question" : "(How Many/How Much) meat do you eat everyday?",
        "answer" : "how much"
    },
    8 : {
       "question" : "He doesn't love (her/hers/yours).",
        "answer" : "her"
    },
    9 : {
       "question" : "First, _________, Third",
        "answer" : "second"
    },
    10 : {
       "question" : "January, _____________, March",
        "answer" : "february"
    },
}