def menu():
  print("Menu")
  print("English and Mathematics")
  print("1.English")
  print("2.Mathematics")
  print("Exit")
menu()