print("Welcome to the English Quiz")
print("Ready for the first question?(1 for y, 2 for no)")
usermen = int(input())
if usermen == 1:
  print("The cars and buses ---- very busy today(choose answer below)")
  print("a) Are")
  print ("b) Is")
  print ("c) Be")
  userin = (input())
  if userin == ("a") or ("A"):
    print("correct answer!")
  elif userin == ("b") or ("B"):
    print("Incorrect")
  elif userin == ("c") or ("C"):
    print("Incorrect")
  else:
    print("Incorrect")