print("Welcome to Mathematics Quiz")
print("Ready for the first quiz(1 for y, 2 for n)")
usermen = int(input())
if usermen == 1:
  print("What is 2 + 2 = ?")
  answer = input()
  if answer != "4":
    print("Incorrect, Try again")
  else:
    print("Correct")